﻿namespace ValtechTestChallengeRF
{
    internal class list<T>
    {
        public list()
        {
        }
    }
}